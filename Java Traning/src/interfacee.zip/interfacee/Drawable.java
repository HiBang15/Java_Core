package interfacee;

interface Drawable{
	int RED = 1; 
	int GREEN = 2; 
	int BLUE = 3; 
	int WHILE = 4; 
	int BLACK = 5;
	void draw(int color);//method of Interface
}
