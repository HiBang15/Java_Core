package interfacee;

public class DMDemo {
	public static void main(String[] args) {
		Car car = new Car();
		car.demo();
	}
}
