package interfacee;

interface Fillable extends Drawable{
	void fill(int color);
}
