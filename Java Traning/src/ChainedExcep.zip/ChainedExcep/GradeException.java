package ChainedExcep;

public class GradeException extends StudentException{
}
