package ChainedExcep;

public class StudentException extends Exception{
	public StudentException() {}

}
