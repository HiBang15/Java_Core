package ChainedExcep;

public class Subject {
	private String sjName;//ten mon hoc 
	private float w;//he so mon
	public String getSjName() {
		return sjName;
	}
	public void setSjName(String sjName) {
		this.sjName = sjName;
	}
	public float getW() {
		return w;
	}
	public void setW(float w) {
		this.w = w;
	}
	
	
}
