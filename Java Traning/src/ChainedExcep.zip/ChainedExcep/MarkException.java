package ChainedExcep;

public class MarkException extends StudentException{
//	public MarkException() {}
//	public MarkException(double diem) {
//		System.out.println("Do not spend over 100 points");
//	}

}
